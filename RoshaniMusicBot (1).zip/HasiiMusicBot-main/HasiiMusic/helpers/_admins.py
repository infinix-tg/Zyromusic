# ==============================================================================
# _admins.py - Permissions
# ==============================================================================
# Decorators to restrict commands to admins or authorized users.
# ==============================================================================

from functools import wraps

from pyrogram import StopPropagation, enums, types
from pyrogram.errors import ChatSendPlainForbidden, ChatWriteForbidden

from HasiiMusic import app, db


def admin_check(func):

    # Ensures only admins or sudo users can run the command.
    @wraps(func)
    async def wrapper(_, update: types.Message | types.CallbackQuery, *args, **kwargs):
        # Helper function to send reply (works for messages and callbacks)
        async def reply(text):
            if isinstance(update, types.Message):
                try:
                    return await update.reply_text(text)
                except (ChatSendPlainForbidden, ChatWriteForbidden):
                    return
            else:
                return await update.answer(text, show_alert=True)

        # Handle anonymous admins (from_user is None)
        if not update.from_user:
            return

        # Get chat ID and user ID from update
        chat_id = (
            update.chat.id
            if isinstance(update, types.Message)
            else update.message.chat.id
        )
        user_id = update.from_user.id

        # Get list of admins from database (cached)
        admins = await db.get_admins(chat_id)

        # Sudo users (bot owner) can bypass admin check
        if user_id in app.sudoers:
            return await func(_, update, *args, **kwargs)

        # Check if user is admin
        if user_id not in admins:
            try:
                return await reply(update.lang["user_no_perms"])
            except (ChatSendPlainForbidden, ChatWriteForbidden):
                return

        # User is admin, allow execution
        return await func(_, update, *args, **kwargs)

    return wrapper


def can_manage_vc(func):

    # Ensures the user has permission to manage voice chats.
    @wraps(func)
    async def wrapper(_, update: types.Message | types.CallbackQuery, *args, **kwargs):
        # Get chat ID and user ID
        chat_id = (
            update.chat.id
            if isinstance(update, types.Message)
            else update.message.chat.id
        )

        # Skip if no user (channel post or anonymous admin)
        if not update.from_user:
            return

        user_id = update.from_user.id

        # Sudo users can always manage VC
        if user_id in app.sudoers:
            return await func(_, update, *args, **kwargs)

        # Check if user is in authorized users list
        if await db.is_auth(chat_id, user_id):
            return await func(_, update, *args, **kwargs)

        admins = await db.get_admins(chat_id)
        if user_id in admins:
            return await func(_, update, *args, **kwargs)

        if isinstance(update, types.Message):
            try:
                return await update.reply_text(update.lang["user_no_perms"])
            except (ChatSendPlainForbidden, ChatWriteForbidden):
                return
        else:
            return await update.answer(update.lang["user_no_perms"], show_alert=True)

    return wrapper


async def is_admin(chat_id: int, user_id: int) -> bool:
    if user_id in await db.get_admins(chat_id):
        return True
    try:
        member = await app.get_chat_member(chat_id, user_id)
        return member.status in [
            enums.ChatMemberStatus.ADMINISTRATOR,
            enums.ChatMemberStatus.OWNER,
        ]
    except:
        raise StopPropagation


async def reload_admins(chat_id: int) -> list[int]:
    try:
        admins = [
            admin
            async for admin in app.get_chat_members(
                chat_id, filter=enums.ChatMembersFilter.ADMINISTRATORS
            )
            if not admin.user.is_bot
        ]
        return [admin.user.id for admin in admins]
    except:
        return []


async def is_admin_callback(query: types.CallbackQuery) -> bool:
    
    # Check if callback query sender is admin
    if not query.from_user:
        return False
    
    user_id = query.from_user.id
    chat_id = query.message.chat.id
    
    # Sudo users are always admin
    if user_id in app.sudoers:
        return True
    
    # Check admin list
    admins = await db.get_admins(chat_id)
    return user_id in admins
